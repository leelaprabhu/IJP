/**
 * @author Leela Prabhu
 *
 */
public class ToFrame{
	private Frame currentFrame;
	/**Path to the place 
	 * @param controller
	 */
	public void toFrame(PhotoController controller){
	}
	/**Path from the place
	 * @param controller
	 */
	public void fromFrame(PhotoController controller){
	}
}